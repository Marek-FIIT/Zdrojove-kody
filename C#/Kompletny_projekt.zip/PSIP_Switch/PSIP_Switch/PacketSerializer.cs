﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Linq;

using SharpPcap;
using PacketDotNet;


namespace PSIP_Switch
{
    public class PacketSerializer
    {
        private Queue<TQueuePacket> PacketQueue = new Queue<TQueuePacket>();
        private EventWaitHandle     PacketWait  = new AutoResetEvent(false);
        private Task                QueueTask;
        private bool                Stopped;
        private GUI                 MainForm;

        private class TQueuePacket
        {
            public Port   port;
            public Packet packet;
        }


        public PacketSerializer(GUI oMainForm)
        {
            this.MainForm  = oMainForm;
            this.QueueTask = Task.Run(this.ProcQueue);
        }


        public void Stop()
        {
            this.Stopped = true;
            this.PacketWait.Set();

            this.QueueTask .Wait();
            this.QueueTask .Dispose();
            this.PacketWait.Dispose();
        }


        public void Enqueue(Port port, Packet packet)
        {
            lock (this.PacketQueue)
            {
                this.PacketQueue.Enqueue(new TQueuePacket() { port = port, packet = packet});
                this.PacketWait .Set();
            }
        }


        private void ProcQueue()
        {
            while (this.PacketWait.WaitOne())
            {
                if (this.Stopped)
                    break;

                TQueuePacket oPacket;

                lock (this.PacketQueue)
                {
                    oPacket = this.PacketQueue.Dequeue();

                    if (this.PacketQueue.Count > 0)
                        this.PacketWait.Set();
                }

                //this.MainForm.Invoke(this.MainForm.dprocess_packet, new object[] { oPacket.port, oPacket.packet });
            }
        }
    }
}
