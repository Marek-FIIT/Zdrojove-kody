﻿namespace PSIP_Switch
{
    partial class GUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnStart = new System.Windows.Forms.Button();
            this.grdStatistics = new System.Windows.Forms.DataGridView();
            this.lblCAM = new System.Windows.Forms.Label();
            this.grdCAM = new System.Windows.Forms.DataGridView();
            this.lblStatistics = new System.Windows.Forms.Label();
            this.btnClearStatistics = new System.Windows.Forms.Button();
            this.numTimer = new System.Windows.Forms.NumericUpDown();
            this.lblTimer = new System.Windows.Forms.Label();
            this.btnClearCAM = new System.Windows.Forms.Button();
            this.lblFilters = new System.Windows.Forms.Label();
            this.chbMACsrc = new System.Windows.Forms.CheckBox();
            this.chbIPsrc = new System.Windows.Forms.CheckBox();
            this.txtDstAddress = new System.Windows.Forms.TextBox();
            this.chbMACdst = new System.Windows.Forms.CheckBox();
            this.chbIPdst = new System.Windows.Forms.CheckBox();
            this.txtSrcAddress = new System.Windows.Forms.TextBox();
            this.chbTCP = new System.Windows.Forms.CheckBox();
            this.chbUDP = new System.Windows.Forms.CheckBox();
            this.txtDstPort = new System.Windows.Forms.TextBox();
            this.txtSrcPort = new System.Windows.Forms.TextBox();
            this.btnAddFilter = new System.Windows.Forms.Button();
            this.btnRemoveFilter = new System.Windows.Forms.Button();
            this.btnRemoveAllFilters = new System.Windows.Forms.Button();
            this.grdFilters = new System.Windows.Forms.DataGridView();
            this.chbICMP = new System.Windows.Forms.CheckBox();
            this.chbIN = new System.Windows.Forms.CheckBox();
            this.chbOUT = new System.Windows.Forms.CheckBox();
            this.cbPort = new System.Windows.Forms.ComboBox();
            this.chbPermit = new System.Windows.Forms.CheckBox();
            this.chbDeny = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.grdStatistics)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCAM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdFilters)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(339, 571);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "Start Switch";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // grdStatistics
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdStatistics.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.grdStatistics.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdStatistics.DefaultCellStyle = dataGridViewCellStyle14;
            this.grdStatistics.Location = new System.Drawing.Point(328, 28);
            this.grdStatistics.Name = "grdStatistics";
            this.grdStatistics.RowHeadersVisible = false;
            this.grdStatistics.RowHeadersWidth = 62;
            this.grdStatistics.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.grdStatistics.Size = new System.Drawing.Size(413, 155);
            this.grdStatistics.TabIndex = 2;
            // 
            // lblCAM
            // 
            this.lblCAM.AutoSize = true;
            this.lblCAM.Location = new System.Drawing.Point(10, 9);
            this.lblCAM.Name = "lblCAM";
            this.lblCAM.Size = new System.Drawing.Size(59, 13);
            this.lblCAM.TabIndex = 3;
            this.lblCAM.Text = "CAM table:";
            // 
            // grdCAM
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdCAM.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.grdCAM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdCAM.DefaultCellStyle = dataGridViewCellStyle16;
            this.grdCAM.Location = new System.Drawing.Point(13, 28);
            this.grdCAM.Name = "grdCAM";
            this.grdCAM.ReadOnly = true;
            this.grdCAM.RowHeadersVisible = false;
            this.grdCAM.RowHeadersWidth = 62;
            this.grdCAM.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.grdCAM.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdCAM.Size = new System.Drawing.Size(203, 241);
            this.grdCAM.TabIndex = 4;
            // 
            // lblStatistics
            // 
            this.lblStatistics.AutoSize = true;
            this.lblStatistics.Location = new System.Drawing.Point(325, 9);
            this.lblStatistics.Name = "lblStatistics";
            this.lblStatistics.Size = new System.Drawing.Size(92, 13);
            this.lblStatistics.TabIndex = 5;
            this.lblStatistics.Text = "Protocol statistics:";
            // 
            // btnClearStatistics
            // 
            this.btnClearStatistics.Location = new System.Drawing.Point(328, 189);
            this.btnClearStatistics.Name = "btnClearStatistics";
            this.btnClearStatistics.Size = new System.Drawing.Size(89, 23);
            this.btnClearStatistics.TabIndex = 6;
            this.btnClearStatistics.Text = "Clear Statistics";
            this.btnClearStatistics.UseVisualStyleBackColor = true;
            this.btnClearStatistics.Click += new System.EventHandler(this.BtnClearStatistics_Click);
            // 
            // numTimer
            // 
            this.numTimer.Location = new System.Drawing.Point(74, 276);
            this.numTimer.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numTimer.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numTimer.Name = "numTimer";
            this.numTimer.Size = new System.Drawing.Size(45, 20);
            this.numTimer.TabIndex = 7;
            this.numTimer.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.numTimer.ValueChanged += new System.EventHandler(this.NumTimer_ValueChanged);
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(10, 278);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(62, 13);
            this.lblTimer.TabIndex = 8;
            this.lblTimer.Text = "CAM Timer:";
            // 
            // btnClearCAM
            // 
            this.btnClearCAM.Location = new System.Drawing.Point(141, 275);
            this.btnClearCAM.Name = "btnClearCAM";
            this.btnClearCAM.Size = new System.Drawing.Size(75, 23);
            this.btnClearCAM.TabIndex = 9;
            this.btnClearCAM.Text = "Clear CAM";
            this.btnClearCAM.UseVisualStyleBackColor = true;
            this.btnClearCAM.Click += new System.EventHandler(this.BtnClearCAM_Click);
            // 
            // lblFilters
            // 
            this.lblFilters.AutoSize = true;
            this.lblFilters.Location = new System.Drawing.Point(10, 343);
            this.lblFilters.Name = "lblFilters";
            this.lblFilters.Size = new System.Drawing.Size(67, 13);
            this.lblFilters.TabIndex = 10;
            this.lblFilters.Text = "Traffic filters:";
            // 
            // chbMACsrc
            // 
            this.chbMACsrc.AutoSize = true;
            this.chbMACsrc.Location = new System.Drawing.Point(326, 364);
            this.chbMACsrc.Name = "chbMACsrc";
            this.chbMACsrc.Size = new System.Drawing.Size(49, 17);
            this.chbMACsrc.TabIndex = 11;
            this.chbMACsrc.Text = "MAC";
            this.chbMACsrc.UseVisualStyleBackColor = true;
            // 
            // chbIPsrc
            // 
            this.chbIPsrc.AutoSize = true;
            this.chbIPsrc.Location = new System.Drawing.Point(381, 363);
            this.chbIPsrc.Name = "chbIPsrc";
            this.chbIPsrc.Size = new System.Drawing.Size(36, 17);
            this.chbIPsrc.TabIndex = 12;
            this.chbIPsrc.Text = "IP";
            this.chbIPsrc.UseVisualStyleBackColor = true;
            // 
            // txtDstAddress
            // 
            this.txtDstAddress.Location = new System.Drawing.Point(220, 386);
            this.txtDstAddress.Name = "txtDstAddress";
            this.txtDstAddress.Size = new System.Drawing.Size(100, 20);
            this.txtDstAddress.TabIndex = 13;
            this.txtDstAddress.Text = "Destination Address";
            // 
            // chbMACdst
            // 
            this.chbMACdst.AutoSize = true;
            this.chbMACdst.Location = new System.Drawing.Point(220, 363);
            this.chbMACdst.Name = "chbMACdst";
            this.chbMACdst.Size = new System.Drawing.Size(49, 17);
            this.chbMACdst.TabIndex = 14;
            this.chbMACdst.Text = "MAC";
            this.chbMACdst.UseVisualStyleBackColor = true;
            // 
            // chbIPdst
            // 
            this.chbIPdst.AutoSize = true;
            this.chbIPdst.Location = new System.Drawing.Point(272, 364);
            this.chbIPdst.Name = "chbIPdst";
            this.chbIPdst.Size = new System.Drawing.Size(36, 17);
            this.chbIPdst.TabIndex = 15;
            this.chbIPdst.Text = "IP";
            this.chbIPdst.UseVisualStyleBackColor = true;
            // 
            // txtSrcAddress
            // 
            this.txtSrcAddress.Location = new System.Drawing.Point(326, 386);
            this.txtSrcAddress.Name = "txtSrcAddress";
            this.txtSrcAddress.Size = new System.Drawing.Size(100, 20);
            this.txtSrcAddress.TabIndex = 16;
            this.txtSrcAddress.Text = "Source Address";
            // 
            // chbTCP
            // 
            this.chbTCP.AutoSize = true;
            this.chbTCP.Location = new System.Drawing.Point(444, 363);
            this.chbTCP.Name = "chbTCP";
            this.chbTCP.Size = new System.Drawing.Size(47, 17);
            this.chbTCP.TabIndex = 17;
            this.chbTCP.Text = "TCP";
            this.chbTCP.UseVisualStyleBackColor = true;
            // 
            // chbUDP
            // 
            this.chbUDP.AutoSize = true;
            this.chbUDP.Location = new System.Drawing.Point(492, 363);
            this.chbUDP.Name = "chbUDP";
            this.chbUDP.Size = new System.Drawing.Size(49, 17);
            this.chbUDP.TabIndex = 18;
            this.chbUDP.Text = "UDP";
            this.chbUDP.UseVisualStyleBackColor = true;
            // 
            // txtDstPort
            // 
            this.txtDstPort.Location = new System.Drawing.Point(550, 386);
            this.txtDstPort.Name = "txtDstPort";
            this.txtDstPort.Size = new System.Drawing.Size(100, 20);
            this.txtDstPort.TabIndex = 19;
            this.txtDstPort.Text = "Destination Port";
            // 
            // txtSrcPort
            // 
            this.txtSrcPort.Location = new System.Drawing.Point(444, 386);
            this.txtSrcPort.Name = "txtSrcPort";
            this.txtSrcPort.Size = new System.Drawing.Size(100, 20);
            this.txtSrcPort.TabIndex = 20;
            this.txtSrcPort.Text = "Source Port";
            // 
            // btnAddFilter
            // 
            this.btnAddFilter.Location = new System.Drawing.Point(666, 384);
            this.btnAddFilter.Name = "btnAddFilter";
            this.btnAddFilter.Size = new System.Drawing.Size(75, 23);
            this.btnAddFilter.TabIndex = 21;
            this.btnAddFilter.Text = "Add";
            this.btnAddFilter.UseVisualStyleBackColor = true;
            this.btnAddFilter.Click += new System.EventHandler(this.btnAddFilter_Click);
            // 
            // btnRemoveFilter
            // 
            this.btnRemoveFilter.Location = new System.Drawing.Point(585, 531);
            this.btnRemoveFilter.Name = "btnRemoveFilter";
            this.btnRemoveFilter.Size = new System.Drawing.Size(75, 23);
            this.btnRemoveFilter.TabIndex = 22;
            this.btnRemoveFilter.Text = "Remove";
            this.btnRemoveFilter.UseVisualStyleBackColor = true;
            this.btnRemoveFilter.Click += new System.EventHandler(this.btnRemoveFilter_Click);
            // 
            // btnRemoveAllFilters
            // 
            this.btnRemoveAllFilters.Location = new System.Drawing.Point(666, 531);
            this.btnRemoveAllFilters.Name = "btnRemoveAllFilters";
            this.btnRemoveAllFilters.Size = new System.Drawing.Size(75, 23);
            this.btnRemoveAllFilters.TabIndex = 23;
            this.btnRemoveAllFilters.Text = "Remove all";
            this.btnRemoveAllFilters.UseVisualStyleBackColor = true;
            this.btnRemoveAllFilters.Click += new System.EventHandler(this.btnRemoveAllFilters_Click);
            // 
            // grdFilters
            // 
            this.grdFilters.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdFilters.Location = new System.Drawing.Point(13, 411);
            this.grdFilters.Name = "grdFilters";
            this.grdFilters.RowHeadersVisible = false;
            this.grdFilters.RowHeadersWidth = 62;
            this.grdFilters.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.grdFilters.Size = new System.Drawing.Size(727, 114);
            this.grdFilters.TabIndex = 24;
            // 
            // chbICMP
            // 
            this.chbICMP.AutoSize = true;
            this.chbICMP.Location = new System.Drawing.Point(543, 363);
            this.chbICMP.Margin = new System.Windows.Forms.Padding(2);
            this.chbICMP.Name = "chbICMP";
            this.chbICMP.Size = new System.Drawing.Size(52, 17);
            this.chbICMP.TabIndex = 25;
            this.chbICMP.Text = "ICMP";
            this.chbICMP.UseVisualStyleBackColor = true;
            // 
            // chbIN
            // 
            this.chbIN.AutoSize = true;
            this.chbIN.Location = new System.Drawing.Point(167, 368);
            this.chbIN.Margin = new System.Windows.Forms.Padding(2);
            this.chbIN.Name = "chbIN";
            this.chbIN.Size = new System.Drawing.Size(37, 17);
            this.chbIN.TabIndex = 26;
            this.chbIN.Text = "IN";
            this.chbIN.UseVisualStyleBackColor = true;
            // 
            // chbOUT
            // 
            this.chbOUT.AutoSize = true;
            this.chbOUT.Location = new System.Drawing.Point(167, 389);
            this.chbOUT.Margin = new System.Windows.Forms.Padding(2);
            this.chbOUT.Name = "chbOUT";
            this.chbOUT.Size = new System.Drawing.Size(49, 17);
            this.chbOUT.TabIndex = 27;
            this.chbOUT.Text = "OUT";
            this.chbOUT.UseVisualStyleBackColor = true;
            // 
            // cbPort
            // 
            this.cbPort.FormattingEnabled = true;
            this.cbPort.Location = new System.Drawing.Point(74, 385);
            this.cbPort.Margin = new System.Windows.Forms.Padding(2);
            this.cbPort.Name = "cbPort";
            this.cbPort.Size = new System.Drawing.Size(82, 21);
            this.cbPort.TabIndex = 28;
            this.cbPort.Text = "Port";
            // 
            // chbPermit
            // 
            this.chbPermit.AutoSize = true;
            this.chbPermit.Location = new System.Drawing.Point(13, 368);
            this.chbPermit.Margin = new System.Windows.Forms.Padding(2);
            this.chbPermit.Name = "chbPermit";
            this.chbPermit.Size = new System.Drawing.Size(55, 17);
            this.chbPermit.TabIndex = 29;
            this.chbPermit.Text = "Permit";
            this.chbPermit.UseVisualStyleBackColor = true;
            // 
            // chbDeny
            // 
            this.chbDeny.AutoSize = true;
            this.chbDeny.Location = new System.Drawing.Point(13, 389);
            this.chbDeny.Margin = new System.Windows.Forms.Padding(2);
            this.chbDeny.Name = "chbDeny";
            this.chbDeny.Size = new System.Drawing.Size(51, 17);
            this.chbDeny.TabIndex = 30;
            this.chbDeny.Text = "Deny";
            this.chbDeny.UseVisualStyleBackColor = true;
            // 
            // GUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 606);
            this.Controls.Add(this.chbDeny);
            this.Controls.Add(this.chbPermit);
            this.Controls.Add(this.cbPort);
            this.Controls.Add(this.chbOUT);
            this.Controls.Add(this.chbIN);
            this.Controls.Add(this.chbICMP);
            this.Controls.Add(this.grdFilters);
            this.Controls.Add(this.btnRemoveAllFilters);
            this.Controls.Add(this.btnRemoveFilter);
            this.Controls.Add(this.btnAddFilter);
            this.Controls.Add(this.txtSrcPort);
            this.Controls.Add(this.txtDstPort);
            this.Controls.Add(this.chbUDP);
            this.Controls.Add(this.chbTCP);
            this.Controls.Add(this.txtSrcAddress);
            this.Controls.Add(this.chbIPdst);
            this.Controls.Add(this.chbMACdst);
            this.Controls.Add(this.txtDstAddress);
            this.Controls.Add(this.chbIPsrc);
            this.Controls.Add(this.chbMACsrc);
            this.Controls.Add(this.lblFilters);
            this.Controls.Add(this.btnClearCAM);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.numTimer);
            this.Controls.Add(this.btnClearStatistics);
            this.Controls.Add(this.lblStatistics);
            this.Controls.Add(this.grdCAM);
            this.Controls.Add(this.lblCAM);
            this.Controls.Add(this.grdStatistics);
            this.Controls.Add(this.btnStart);
            this.MaximumSize = new System.Drawing.Size(769, 645);
            this.MinimumSize = new System.Drawing.Size(769, 645);
            this.Name = "GUI";
            this.Text = "Software switch";
            ((System.ComponentModel.ISupportInitialize)(this.grdStatistics)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCAM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTimer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdFilters)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.DataGridView grdStatistics;
        private System.Windows.Forms.Label lblCAM;
        private System.Windows.Forms.DataGridView grdCAM;
        private System.Windows.Forms.Label lblStatistics;
        private System.Windows.Forms.Button btnClearStatistics;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button btnClearCAM;
        public System.Windows.Forms.NumericUpDown numTimer;
        private System.Windows.Forms.Label lblFilters;
        private System.Windows.Forms.CheckBox chbMACsrc;
        private System.Windows.Forms.CheckBox chbIPsrc;
        private System.Windows.Forms.TextBox txtDstAddress;
        private System.Windows.Forms.CheckBox chbMACdst;
        private System.Windows.Forms.CheckBox chbIPdst;
        private System.Windows.Forms.TextBox txtSrcAddress;
        private System.Windows.Forms.CheckBox chbTCP;
        private System.Windows.Forms.CheckBox chbUDP;
        private System.Windows.Forms.TextBox txtDstPort;
        private System.Windows.Forms.TextBox txtSrcPort;
        private System.Windows.Forms.Button btnAddFilter;
        private System.Windows.Forms.Button btnRemoveFilter;
        private System.Windows.Forms.Button btnRemoveAllFilters;
        private System.Windows.Forms.DataGridView grdFilters;
        private System.Windows.Forms.CheckBox chbICMP;
        private System.Windows.Forms.CheckBox chbIN;
        private System.Windows.Forms.CheckBox chbOUT;
        private System.Windows.Forms.ComboBox cbPort;
        private System.Windows.Forms.CheckBox chbPermit;
        private System.Windows.Forms.CheckBox chbDeny;
    }
}

